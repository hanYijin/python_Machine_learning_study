# -*- coding: utf-8 -*- 
# 데이터를 학습... 
# 1번 사람이 어떤게 조금씩 다른지 학습....
# 2번 사람이 어떤 사진들이 다른지 학습...
import cv2 # 많은 알고리즘... 시키... 샤캬... 
import numpy as np  # 그레이... 배열화...
from PIL import Image   # 이미지 가져오기
import os   # 파일경로 확인

# Path for face image database
path = 'dataset'
recognizer = cv2.face.LBPHFaceRecognizer_create()
detector = cv2.CascadeClassifier("haarcascades/haarcascade_frontalface_default.xml")

# function to get the images and label data
def getImagesAndLabels(path):
    imagePaths = [os.path.join(path,f) for f in os.listdir(path)]     
    faceSamples=[]
    ids = []
    for imagePath in imagePaths:
        PIL_img = Image.open(imagePath).convert('L') # convert it to grayscale
        img_numpy = np.array(PIL_img,'uint8')
        print(os.path.split(imagePath))
        id = int(os.path.split(imagePath)[-1].split("-")[1])    # 0 unknown, 1 pmh
        faces = detector.detectMultiScale(img_numpy)
        for (x,y,w,h) in faces:
            faceSamples.append(img_numpy[y:y+h,x:x+w])
            ids.append(id)
    return faceSamples,ids
print ("\n [INFO] Training faces. It will take a few seconds. Wait ...")
faces,ids = getImagesAndLabels(path)
recognizer.train(faces, np.array(ids))

# Save the model into trainer/trainer.yml
recognizer.write('trainer/trainer.yml') # recognizer.save() worked on Mac, but not on Pi
# Print the numer of faces trained and end program
print("\n [INFO] {0} faces trained. Exiting Program".format(len(np.unique(ids))))